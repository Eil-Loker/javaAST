package Expression;

public class SimpleReference {
    public static void main(String[] args) {
        int x = 10;
        // println(x)是一个SimpleReference节点，代表变量x的简单引用
        System.out.println(x);
    }
}
