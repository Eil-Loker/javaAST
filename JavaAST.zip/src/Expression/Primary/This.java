package Expression.Primary;

public class This {
    private int value;

    public void setValue(int value) {
        // this关键字就是一个this节点
        this.value = value;
    }
}
