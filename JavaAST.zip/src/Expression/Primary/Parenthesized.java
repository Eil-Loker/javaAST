package Expression.Primary;

public class Parenthesized {
    public static void main(String[] args) {
        // (5 + 3)是一个Parenthesized，代表括号表达式
        int result = (5 + 3) * 2;
        System.out.println(result);
    }
}
