package Expression.Primary;

public class InstanceCreationTmp {
}
