package Expression.Primary;

/**
 * 值
 */

public class Literal {
    String Literal = "Hello world!";
}
