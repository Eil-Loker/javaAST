package Expression.Primary;

public class Primary {
    public static void main(String[] args) {
        // Primary代表基本表达式，可以是String primary，或 "Hello World"，或者obj.field，或者变量primary等等
        String primary = "Hello World";
    }
}