package Expression.Primary;

import java.util.HashMap;
import java.util.Map;

public class ClassLiteral {
    public static void main(String[] args) {
        Map<String,String> map = new HashMap<>();
    }
}
