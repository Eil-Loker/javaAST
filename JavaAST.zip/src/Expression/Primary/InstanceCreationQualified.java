package Expression.Primary;

/**
 * 无此AST节点
 */

public class InstanceCreationQualified {
}
