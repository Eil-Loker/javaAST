package Expression.Primary;

public class InstanceCreation {
}
