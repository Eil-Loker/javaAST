package Expression;

public class Binary {
    public static void main(String[] args) {
        // 10 + 5中的+就是一个Binary，代表双目运算符，还包括下面的==
        int result = 10 + 5;
        boolean isEqual = (result == 15);
    }
}
