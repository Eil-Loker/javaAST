package Expression;

public class Cast {
    public static void main(String[] args) {
        double num = 3.14;
        // (int) num是一个Cast节点，代表类型转换
        int roundedNum = (int) num;
    }
}
