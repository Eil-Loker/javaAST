package Expression;

public class Expression {
    public static void main(String[] args) {
        int x = 5;
        int y = 10;
        // x + y 是一个Expression节点，代表一个表达式，表达式包含多种，包括变量、值、运算符，方法调用，或其他表达式等
        int result = x + y;
        System.out.println(result);
    }
}
