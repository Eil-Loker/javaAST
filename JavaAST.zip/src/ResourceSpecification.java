public class ResourceSpecification {
}
