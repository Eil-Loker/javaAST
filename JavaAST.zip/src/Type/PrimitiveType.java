package Type;

public class PrimitiveType {
    public static void main(String[] args) {
        // PrimitiveType表示基本数据类型，Java有8种基本数据类型boolean、byte、short、int、long、float、double、char
        boolean flag = true; // PrimitiveType: boolean
        int count = 10; // PrimitiveType: int
        double pi = 3.14159; // PrimitiveType: double
        char ch = 'A'; // PrimitiveType: char
    }
}
