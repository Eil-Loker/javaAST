package Type;

import java.util.ArrayList;
import java.util.List;

public class TypeName {
    public static void main(String[] args) {
        // TypeName包含其中的String、List、ArrayList
        List<String> myList = new ArrayList<>();
    }
}
