package Type;

public class UnannotatedType {
}
