public class AnnoElementValue {
}
