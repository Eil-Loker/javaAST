public class Dim {
    // Dim代表数据维度，例如int[3][4]包含两个Dim节点，第一个节点长度为3，第二个节点长度为4
    int[][] matrix = new int[3][4];
}
