public @interface MyAnnotation {
    String value() default "default value";
}
