public class CompoundName {
    public static void main(String[] args) {
        // CompoundName代表类的完全限定名，例如Expression.Primary.Literal
        Expression.Primary.Literal otherClass = new Expression.Primary.Literal();
    }
}
