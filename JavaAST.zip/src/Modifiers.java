public class Modifiers {
    // private、public、static、final都是Modifiers，代表修饰符
    private static final int MAX_VALUE = 100;

    public static void main(String[] args) {
        // Method implementation
    }
}
