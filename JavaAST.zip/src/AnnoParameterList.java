// AnnoParameterList表示注解中的值，例如"specific value"
@MyAnnotation(value = "specific value")
public class AnnoParameterList {
}