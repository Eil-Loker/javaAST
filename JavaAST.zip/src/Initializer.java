public class Initializer {
    static {
        // Static initializer block
        // Code executed when the class is loaded
    }
}
